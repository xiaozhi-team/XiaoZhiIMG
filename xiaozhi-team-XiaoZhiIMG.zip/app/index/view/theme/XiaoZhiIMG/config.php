<?php
/**
 * 主题配置文件
 * User: WispX
 * Date: 2017/9/23
 * Time: 8:53
 * Link: http://gitee.com/wispx
 */
return [
    'name'      => 'XiaoZhiIMG',
    'key'       => 'XiaoZhiIMG',
    'author'    => 'XiaoZhiBoy',
    'explain'   => 'XiaoZhiIMG官方主题',
    'images'    => '/static/themes/images/XiaoZhiIMG/preview.jpg', // 除官方外，这里必须是绝对路径
    'link'      => 'http://83883.top/',
];