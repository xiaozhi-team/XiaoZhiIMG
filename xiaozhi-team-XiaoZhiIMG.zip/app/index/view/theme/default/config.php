<?php
/**
 * 主题配置文件
 * User: WispX
 * Date: 2017/9/23
 * Time: 8:53
 * Link: http://gitee.com/wispx
 */
return [
    'name'      => '默认',
    'key'       => 'default',
    'author'    => 'WispX',
    'explain'   => '官方默认主题',
    'images'    => '/static/theme/imagess/default/preview.jpg', // 除官方外，这里必须是绝对路径
    'link'      => 'http://www.xlogs.cn',
];