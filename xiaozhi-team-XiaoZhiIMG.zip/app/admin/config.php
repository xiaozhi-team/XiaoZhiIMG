<?php
/**
 * admin模块配置
 * User: WispX
 * Date: 2017/9/15
 * Time: 15:30
 */
return [

];